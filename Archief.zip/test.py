import helpers

genomeBefore = [0, 23, 1, 2, 11, 24, 22, 19, 20, 25, 7, 10, 6, 5, 8, 18, 12, 13, 14, 15, 16, 17, 21, 3, 4, 9, 26]
genome =        [0, 23, 1, 2, 11, 24, 22, 19, 20, 25, 7, 10, 6, 5, 4, 3, 21, 17, 16, 15, 14, 13, 12, 18, 8, 9, 26]
genomeNa = [0, 23, 1, 2, 11, 24, 22, 19, 20, 25, 7, 10, 9, 8, 18, 12, 13, 14, 15, 16, 17, 21, 3, 4, 5, 6, 26]

breakpointList = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 21, 22, 23, 24, 25]

BreakpointList 12 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 21, 22, 23, 24, 25]
BreakpointList 13 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 15, 16, 21, 22, 23, 24, 25, 11, 12]
BreakpointList 23 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 16, 21, 22, 23, 24, 25, 11, 12]
BreakpointList 24 [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 16, 21, 22, 23, 24, 25, 11, 12, 22, 23, 24, 23]
BREAKPOINTLIST [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 16, 21, 22, 23, 24, 25]
Genome [0, 23, 1, 2, 11, 24, 22, 19, 20, 25, 7, 10, 6, 5, 4, 3, 21, 17, 16, 15, 14, 13, 12, 18, 8, 9, 26]




i = 14 - 1
j = 24 - 1


# https://gyazo.com/9389e6324f980a2bee57a173f5358a91  <--- dit geval eruit halen
# print("old", breakpointList)
newList = []

for m in [i - 1, i, j, j + 1]:
    print("BreakpointList", m, breakpointList)
    if abs (genome[m - 1] - genome[m] ) == 1:
        if m < len ( genome ) - 1:
            if m in breakpointList and m not in newList:
                breakpointList.remove ( m )

        if m - 1 > 0:
            if m - 1 in breakpointList and m - 1 not in newList:
                if m - 2 >= 0 and abs ( genome[m - 2] - genome[m - 1] ) == 1:
                    breakpointList.remove ( m - 1 )
    else:
        if m - 1 > 0:
            breakpointList.append ( m - 1 )
            newList.append ( m - 1 )
        if m > 0:

            breakpointList.append ( m )
            newList.append ( m )

    if m + 1 < len ( genome ):
        if abs ( genome[m] - genome[m + 1] ) == 1:
            if m in breakpointList and m not in newList:
                breakpointList.remove ( m )
            if m + 1 in breakpointList and m + 1 not in newList:
                if m + 2 < len ( genome ) and abs ( genome[m + 2] - genome[m + 1] ) == 1:
                    breakpointList.remove ( m + 1 )
        else:
            if m + 1 < len ( genome ) - 1:
                breakpointList.append ( m + 1 )
                newList.append ( m + 1 )
            breakpointList.append ( m )
            newList.append ( m )

    breakpointList = list ( set ( breakpointList ) )

if j - i > 3:
    for m in range(i + 2, j - 1):
        if m in breakpointList:
            copyBreakpointList = breakpointList
            breakpointList[m - 1] =
            j - (m - i)

print("BREAKPOINTLIST", breakpointList)
print("Genome", genome)