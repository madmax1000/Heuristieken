import helpers
import GenomeSequence as genomeClass
import random
import math

branchAndBoundThreshold = 5

melanoGenome = [0,23,1,2,11,24,22,19,6,10,7,25,20,5,8,18,12,13,14,15,16,17,21,3,4,9,26]
#melanoGenome = helpers.RandomMutation(15)

genomeObject = genomeClass.GenomeSequence ( melanoGenome )

mirandaGenome = [i for i in range ( len ( melanoGenome ) )]

numberOfMutations = 0
prevI = -1
prevJ = -1

history = []
print("!FIRST GREEDY STARTED!")
while genomeObject.genome != mirandaGenome:
    numberOfMutations += 1
    genomeObject.genome, i, j, deltaPHI = genomeObject.MutateGreedy ( prevI, prevJ )
    prevI, prevJ = i, j
    history.append ( [i, j, deltaPHI] )
    print ( "Mutation number: ", numberOfMutations, " ", genomeObject.genome)
print ( "Your genome has been solved in ", numberOfMutations, " mutations!\n")

print("History looks like: ", history)
print("Length of history equals: ", len(history), "\n")


# FOR NOW RANDINT, MAAR WE WILLEN MEER KANS VOOR LAGE DEPTH
randomDepth = random.randint(0, numberOfMutations - 2)
print("Chosen randomDepth equals: ", randomDepth)

# clear history after randomDepth
history = history[:randomDepth]
print("History until randomDepth looks like: ", history)

# initialize the genome again
genomeObject = genomeClass.GenomeSequence(melanoGenome)
print("New initialized genome looks like: ", genomeObject.genome)

# mutate the genome UNTIL the specified depth
for mutation in history[:randomDepth]:

    # execute the mutations
    genomeObject.genome = genomeObject.Reverse(mutation[0], mutation[1])
    print("Current genome looks like: ", genomeObject.genome)
    # update the breakpointList
    genomeObject.UpdateBreakpointList(mutation[0], mutation[1])
    print ( "CURRENT BREAKPOINT LIST LOOKS LIKE: ", genomeObject.breakpointList)

    # update the number of breakpoints
    genomeObject.breakpointPairs -= mutation[2]
print("Genome mutated UNTIL random depth looks like: ", genomeObject.genome)

# at CURRENT depth, check all options
optionList = genomeObject.MutateBnB()
print("Right now, our optionList looks like: ", optionList)

# select a RANDOM optionList (either eliminate 2 breakpoints or 1 breakpoint)
rng = random.random()
if rng < 0.7 and len(optionList[0]) > 0:
    selectedList = optionList[0]

    # you know that you're going to eliminate 2 breakpoints!
    genomeObject.breakpointPairs -= 2

    # save deltaPHI to update history a few lines below
    historyPHI = 2
    print("Randomly chosen list is list with index 0")

else:
    selectedList = optionList[1]

    # you know that you're going to eliminate 1 breakpoint!
    genomeObject.breakpointPairs -= 1

    # save deltaPHI to update history a few lines below
    historyPHI = 1
    print("Randomly chosen list is list with index 1")

print("This optionlist looks like: ", selectedList)

# select a RANDOM mutation from the selected optionList
selectedMutation = random.choice(selectedList)
print("Randomly selected mutation from this optionList equals: ", selectedMutation)

# execute the just selected mutation (no need to update the breakpointPairs; already done a few lines above)
genomeObject.genome = genomeObject.Reverse(selectedMutation[0], selectedMutation[1])
genomeObject.UpdateBreakpointList(selectedMutation[0], selectedMutation[1])
print("Executing this mutation results in the following genome: ", genomeObject.genome)

print("CURRENT BREAKPOINT LIST LOOKS LIKE: ", genomeObject.breakpointList)

# update the history with historyPHI from a few lines above
history.append([selectedMutation[0], selectedMutation[1], historyPHI])
print("Updated history looks like: ", history)


# -------- GREEDY PART --------
print("-------- GREEDY PART --------")

# Execute Greedy until the number of breakpointPairs threshold has been reached
print("genomeObject.breakpointPairs = ", genomeObject.breakpointPairs)
print("branchAndBoundThreshold = ", branchAndBoundThreshold)
print("genomeObject.breakpointPairs > branchAndBoundThreshold = ", genomeObject.breakpointPairs > branchAndBoundThreshold)
print("Current genome looks like: ", genomeObject.genome)
prevI = selectedMutation[0]
prevJ = selectedMutation[1]

while genomeObject.breakpointPairs > branchAndBoundThreshold:
    genomeObject.genome, i, j, deltaPHI = genomeObject.MutateGreedy ( prevI, prevJ )
    prevI, prevJ = i, j
    genomeObject.breakpointPairs -= deltaPHI
    history.append([i, j, deltaPHI])
    print("Mutated to: ", genomeObject.genome, prevI, prevJ)

# -------- BRANCH AND BOUND PART --------
print("-------- BRANCH AND BOUND PART --------")

# initialize empty arrays
current = [0] * 32
best = []

# store the breakpointPairs in a variable to give to the BnB function
breakpointPairs = genomeObject.breakpointPairs

# start Branch and Bound!
print("Branch and Bound was started")
upperBound, current, best = helpers.BnB(genomeObject, 0, breakpointPairs , current, best, breakpointPairs, mirandaGenome)

print("History looks like: ", history)
print("Best looks like: ", best)
# store the shortest sequence of mutations (from randomDepth + 1)
best = best[:upperBound]
print("Best looks like: ", best)

totalLength = len(history) + len(best)

numberOfMutations = 0
genomeObject = genomeClass.GenomeSequence(melanoGenome)
for mutation in history:
    numberOfMutations += 1
    genomeObject.genome = genomeObject.Reverse(mutation[0], mutation[1])

for mutation in best:
    numberOfMutations += 1
    genomeObject.genome = genomeObject.Reverse(mutation[0], mutation[1])

print(genomeObject.genome)
print("Your genome has been solved in ", numberOfMutations, " mutations!")